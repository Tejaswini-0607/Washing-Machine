/* 
 * File:   timers.h
 * Author: Lenovo
 *
 * Created on January 31, 2025, 8:00 PM
 */

#ifndef TIMERS_H
#define	TIMERS_H

void init_timer2(void);


#endif	/* TIMERS_H */

